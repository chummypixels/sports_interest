package com.chummypixels.flutter_sports_interest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

//Model class for the various interest a user might have

class InterestType {
  final String asset;
  final String name;

  InterestType(this.asset, this.name);
}
